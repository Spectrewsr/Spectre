运行环境  wsl   或linux

读入txt文件student.txt  在src中

输出output.txt在bin中  可执行文件在bin中

使用cmakefile