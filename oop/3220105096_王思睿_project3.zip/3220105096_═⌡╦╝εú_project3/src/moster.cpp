#include "moster.hpp"
#include <iostream>


Moster::Moster()
{
    this->name = "Moster room";
}

